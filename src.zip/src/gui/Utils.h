#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#include "ofMain.h"

ofVec2f stringToVec2f(string _in);
ofVec3f stringToVec3f(string _in);

#endif // UTILS_H_INCLUDED
